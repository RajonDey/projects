/*
|| Main JS Codes are there 
*/



    // 1st- Click, Shop Link 
    function openShopNav() {
        document.getElementById("mySidenav").style.width = "250px";
    }
    function closeShopNav() {
        document.getElementById("mySidenav").style.width = "0";
    }


    /*
    ---------------------------------------------------
            Online Store Side Nav ()
    ---------------------------------------------------
    */

        // 2nd- Click, in Online Store link
        function openShopByNav() {
            document.getElementById("ShopByNav").style.width = "250px";
        }
        function closeShopByNav() {
            document.getElementById("ShopByNav").style.width = "0";
        }

            // 5th- Click, Shop By Island
            function openShopByIsland() {
                document.getElementById("ShopByIsland").style.width = "250px";
            }
            function closeShopByIsland() {
                document.getElementById("ShopByIsland").style.width = "0";
            }

            // Click, Shop By Store Name
            function openShopByStrName() {
                document.getElementById("ShopByStrName").style.width = "250px";
            }
            function closeShopByStrName() {
                document.getElementById("ShopByStrName").style.width = "0";
            }

            // Click, Shop By Category
            function openShopByCategory() {
                document.getElementById("ShopByCategory").style.width = "250px";
            }
            function closeShopByCategory() {
                document.getElementById("ShopByCategory").style.width = "0";
            }
 
            // Click, Shop By Search
            function openShopBySeach() {
                document.getElementById("ShopBySearch").style.width = "250px";
            }
            function closeShopBySearch() {
                document.getElementById("ShopBySearch").style.width = "0";
            }



    /*
    ---------------------------------------------------
            Grocery Side Nav (G)
    ---------------------------------------------------
    */

        // 2nd- Click, in Grocery link
        function openGShopByNav() {
            document.getElementById("GShopByNav").style.width = "250px";
        }
        function closeGShopByNav() {
            document.getElementById("GShopByNav").style.width = "0";
        }

            // 5th- Click, Shop By Island
            function openGShopByIsland() {
                document.getElementById("GShopByIsland").style.width = "250px";
            }
            function closeGShopByIsland() {
                document.getElementById("GShopByIsland").style.width = "0";
            }

            // Click, Shop By Store Name
            function openGShopByStrName() {
                document.getElementById("GShopByStrName").style.width = "250px";
            }
            function closeGShopByStrName() {
                document.getElementById("GShopByStrName").style.width = "0";
            }

            // Click, Shop By Category
            function openGShopByCategory() {
                document.getElementById("GShopByCategory").style.width = "250px";
            }
            function closeGShopByCategory() {
                document.getElementById("GShopByCategory").style.width = "0";
            }
 
            // Click, Shop By Search
            function openGShopBySeach() {
                document.getElementById("GShopBySearch").style.width = "250px";
            }
            function closeGShopBySearch() {
                document.getElementById("GShopBySearch").style.width = "0";
            }
        


     /*
    ---------------------------------------------------
            Eats Side Nav (E)
    ---------------------------------------------------
    */

        // 2nd- Click, in Eats link
        function openEShopByNav() {
            document.getElementById("EShopByNav").style.width = "250px";
        }
        function closeEShopByNav() {
            document.getElementById("EShopByNav").style.width = "0";
        }

            // 5th- Click, Shop By Island
            function openEShopByIsland() {
                document.getElementById("EShopByIsland").style.width = "250px";
            }
            function closeEShopByIsland() {
                document.getElementById("EShopByIsland").style.width = "0";
            }

            // Click, Shop By Store Name
            function openEShopByStrName() {
                document.getElementById("EShopByStrName").style.width = "250px";
            }
            function closeEShopByStrName() {
                document.getElementById("EShopByStrName").style.width = "0";
            }

            // Click, Shop By Category
            function openEShopByCategory() {
                document.getElementById("EShopByCategory").style.width = "250px";
            }
            function closeEShopByCategory() {
                document.getElementById("EShopByCategory").style.width = "0";
            }
 
            // Click, Shop By Search
            function openEShopBySeach() {
                document.getElementById("EShopBySearch").style.width = "250px";
            }
            function closeEShopBySearch() {
                document.getElementById("EShopBySearch").style.width = "0";
            }
        


    /*
    ---------------------------------------------------
            Fresh Side Nav (F)
    ---------------------------------------------------
    */

        // 2nd- Click, in Fresh link
        function openFShopByNav() {
            document.getElementById("FShopByNav").style.width = "250px";
        }
        function closeFShopByNav() {
            document.getElementById("FShopByNav").style.width = "0";
        }

            // 5th- Click, Shop By Island
            function openFShopByIsland() {
                document.getElementById("FShopByIsland").style.width = "250px";
            }
            function closeFShopByIsland() {
                document.getElementById("FShopByIsland").style.width = "0";
            }

            // Click, Shop By Store Name
            function openFShopByStrName() {
                document.getElementById("FShopByStrName").style.width = "250px";
            }
            function closeFShopByStrName() {
                document.getElementById("FShopByStrName").style.width = "0";
            }

            // Click, Shop By Category
            function openFShopByCategory() {
                document.getElementById("FShopByCategory").style.width = "250px";
            }
            function closeFShopByCategory() {
                document.getElementById("FShopByCategory").style.width = "0";
            }
 
            // Click, Shop By Search
            function openFShopBySeach() {
                document.getElementById("FShopBySearch").style.width = "250px";
            }
            function closeFShopBySearch() {
                document.getElementById("FShopBySearch").style.width = "0";
            }


    /*
    ---------------------------------------------------
            Home Srrvice Side Nav (H)
    ---------------------------------------------------
    */

        // 2nd - Click, in Home Srrvice link
        function openHShopByNav() {
            document.getElementById("HShopByNav").style.width = "250px";
        }
        function closeHShopByNav() {
            document.getElementById("HShopByNav").style.width = "0";
        }

            // 5th- Click, Shop By Island
            function openHShopByIsland() {
                document.getElementById("HShopByIsland").style.width = "250px";
            }
            function closeHShopByIsland() {
                document.getElementById("HShopByIsland").style.width = "0";
            }

            // Click, Shop By Store Name
            function openHShopByStrName() {
                document.getElementById("HShopByStrName").style.width = "250px";
            }
            function closeHShopByStrName() {
                document.getElementById("HShopByStrName").style.width = "0";
            }

            // Click, Shop By Category
            function openHShopByCategory() {
                document.getElementById("HShopByCategory").style.width = "250px";
            }
            function closeHShopByCategory() {
                document.getElementById("HShopByCategory").style.width = "0";
            }
 
            // Click, Shop By Search
            function openHShopBySeach() {
                document.getElementById("HShopBySearch").style.width = "250px";
            }
            function closeHShopBySearch() {
                document.getElementById("HShopBySearch").style.width = "0";
            }

    /*
    ---------------------------------------------------
            Pro Srrvice Side Nav (P)
    ---------------------------------------------------
    */

        // 2nd - Click, in Home Srrvice link
        function openPShopByNav() {
            document.getElementById("PShopByNav").style.width = "250px";
        }
        function closePShopByNav() {
            document.getElementById("PShopByNav").style.width = "0";
        }

            // 5th- Click, Shop By Island
            function openPShopByIsland() {
                document.getElementById("PShopByIsland").style.width = "250px";
            }
            function closePShopByIsland() {
                document.getElementById("PShopByIsland").style.width = "0";
            }

            // Click, Shop By Store Name
            function openPShopByStrName() {
                document.getElementById("PShopByStrName").style.width = "250px";
            }
            function closePShopByStrName() {
                document.getElementById("PShopByStrName").style.width = "0";
            }

            // Click, Shop By Category
            function openPShopByCategory() {
                document.getElementById("PShopByCategory").style.width = "250px";
            }
            function closePShopByCategory() {
                document.getElementById("PShopByCategory").style.width = "0";
            }
 
            // Click, Shop By Search
            function openPShopBySeach() {
                document.getElementById("PShopBySearch").style.width = "250px";
            }
            function closePShopBySearch() {
                document.getElementById("PShopBySearch").style.width = "0";
            }

             

             


$(document).ready(function(){

    

    //Carousel of todays deal
    $('.owl-deal').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        autoplay:true,
        autoplayTimeout:3000,
        //autoplayHoverPause:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:3
            },
            1000:{
                items:6
            }
        }
    });

    //Carousel of Discount Product
    $('.owl-discount').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        autoplay:true,
        autoplayTimeout:3000,
        //autoplayHoverPause:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:5
            }
        }
    });

    // Carousel One
    $('.owl-one').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        autoplay:true,
        autoplayTimeout:3000,
        //autoplayHoverPause:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:4
            }
        }
    });

    // Carousel Two
    $('.owl-two').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        responsive:{
            0:{
                items:2
            },
            600:{
                items:4
            },
            1000:{
                items:7
            }
        }
    });


     // Carousel three
    $('.owl-three').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        responsive:{
            0:{
                items:2
            },
            600:{
                items:3
            },
            1000:{
                items:4
            }
        }
    });




    // Show More Function
    $(function () {
        if ($(window).width() > 767){
            $(".show").slice(0, 12).show();
            $("#showMore").on('click', function (e) {
                e.preventDefault();
                $(".show:hidden").slice(0, 6).slideDown();
                if ($(".show:hidden").length == 0) {
                    $("#load").fadeOut('slow');
                }
                $('html,body').animate({
                    scrollTop: $(this).offset().top
                }, 1500);
            })
        }else{
            $(".show").slice(0, 4).show();
            $("#showMore").on('click', function (e) {
                e.preventDefault();
                $(".show:hidden").slice(0, 4).slideDown();
                if ($(".show:hidden").length == 0) {
                    $("#load").fadeOut('slow');
                }
                $('html,body').animate({
                    scrollTop: $(this).offset().top
                }, 1500);
            })
        };


    });




    // Back to TOP function
    $('.top').click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 1000);
        return false;
    });




    // Custom Select File
    document.querySelector("html").classList.add('js');

    var fileInput  = document.querySelector( ".input-file" ),  
        button     = document.querySelector( ".input-file-trigger" ),
        the_return = document.querySelector(".file-return");
          
    button.addEventListener( "keydown", function( event ) {  
        if ( event.keyCode == 13 || event.keyCode == 32 ) {  
            fileInput.focus();  
        }  
    });
    button.addEventListener( "click", function( event ) {
       fileInput.focus();
       return false;
    });  
    fileInput.addEventListener( "change", function( event ) {  
        the_return.innerHTML = this.value;  
    });  





});




// For side nav drop-down

var dropdown = document.getElementsByClassName("dropdown-Link");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}; 


// See More function for different listing

// Load More Function
$(function () {
    $(".see").slice(0, 2).show();
    $("#seeMore").on('click', function (e) {
        e.preventDefault();
        $(".see:hidden").slice(0, 1).slideDown();
        if ($(".see:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
// Load More Function
$(function () {
    $(".see2").slice(0, 2).show();
    $("#seeMore2").on('click', function (e) {
        e.preventDefault();
        $(".see2:hidden").slice(0, 1).slideDown();
        if ($(".see2:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
// Load More Function
$(function () {
    $(".see3").slice(0, 2).show();
    $("#seeMore3").on('click', function (e) {
        e.preventDefault();
        $(".see3:hidden").slice(0, 1).slideDown();
        if ($(".see3:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
// Load More Function
$(function () {
    $(".see4").slice(0, 2).show();
    $("#seeMore4").on('click', function (e) {
        e.preventDefault();
        $(".see4:hidden").slice(0, 1).slideDown();
        if ($(".see4:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});


// Load More Function
$(function () {
    $(".see5").slice(0, 2).show();
    $("#seeMore5").on('click', function (e) {
        e.preventDefault();
        $(".see5:hidden").slice(0, 1).slideDown();
        if ($(".see5:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
// Load More Function
$(function () {
    $(".see6").slice(0, 2).show();
    $("#seeMore6").on('click', function (e) {
        e.preventDefault();
        $(".see6:hidden").slice(0, 1).slideDown();
        if ($(".see6:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
// Load More Function
$(function () {
    $(".see7").slice(0, 2).show();
    $("#seeMore7").on('click', function (e) {
        e.preventDefault();
        $(".see7:hidden").slice(0, 1).slideDown();
        if ($(".see7:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
// Load More Function
$(function () {
    $(".see8").slice(0, 2).show();
    $("#seeMore8").on('click', function (e) {
        e.preventDefault();
        $(".see8:hidden").slice(0, 1).slideDown();
        if ($(".see8:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});


// Load More Function
$(function () {
    $(".see9").slice(0, 2).show();
    $("#seeMore9").on('click', function (e) {
        e.preventDefault();
        $(".see9:hidden").slice(0, 1).slideDown();
        if ($(".see9:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
// Load More Function
$(function () {
    $(".see10").slice(0, 2).show();
    $("#seeMore10").on('click', function (e) {
        e.preventDefault();
        $(".see10:hidden").slice(0, 1).slideDown();
        if ($(".see10:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
// Load More Function
$(function () {
    $(".see11").slice(0, 2).show();
    $("#seeMore11").on('click', function (e) {
        e.preventDefault();
        $(".see11:hidden").slice(0, 1).slideDown();
        if ($(".see11:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
// Load More Function
$(function () {
    $(".see12").slice(0, 2).show();
    $("#seeMore12").on('click', function (e) {
        e.preventDefault();
        $(".see12:hidden").slice(0, 1).slideDown();
        if ($(".see12:hidden").length == 0) {
            $("#load").fadeOut('slow');
        }
    });
});
